import requests
import xbmcplugin
import xbmcgui
import sys
import urllib.parse
from datetime import datetime

BASE_URL = 'https://ppv.land'
API_URL = f'{BASE_URL}/api/streams'

LOGO_ICON = "icon.png"

def fetch_streams():
    try:
        response = requests.get(API_URL)
        response.raise_for_status()
        return response.json().get('streams', [])
    except requests.RequestException as e:
        xbmcgui.Dialog().notification('Error', f'Failed to fetch streams: {e}', xbmcgui.NOTIFICATION_ERROR)
        return []

def is_live(stream):
    try:
        now = datetime.utcnow()
        start_time = datetime.strptime(stream['starts_at'], "%Y-%m-%dT%H:%M:%SZ")
        end_time = datetime.strptime(stream['ends_at'], "%Y-%m-%dT%H:%M:%SZ")
        return start_time <= now <= end_time
    except Exception:
        return False

def list_categories():
    streams = fetch_streams()
    li = xbmcgui.ListItem(label="[B]🏆 Welcome to PrezZidental Sports![/B]")
    li.setArt({'thumb': LOGO_ICON, 'icon': LOGO_ICON, 'fanart': LOGO_ICON})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url='', listitem=li, isFolder=False)

    live_streams = [stream for category in streams for stream in category['streams'] if is_live(stream)]
    
    if live_streams:
        li = xbmcgui.ListItem(label="[B]🔥 Live Now[/B]")
        li.setArt({'thumb': LOGO_ICON, 'icon': LOGO_ICON, 'fanart': LOGO_ICON})
        url = f'{sys.argv[0]}?action=list_live_now'
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)

    for category in streams:
        li = xbmcgui.ListItem(label=category['category'])
        url = f'{sys.argv[0]}?action=list_streams&category_id={category["id"]}'
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def list_live_now():
    streams = fetch_streams()
    live_streams = [stream for category in streams for stream in category['streams'] if is_live(stream)]

    for stream in live_streams:
        li = xbmcgui.ListItem(label=f"🔴 {stream['name']}")
        if 'poster' in stream and stream['poster']:
            li.setArt({'thumb': stream['poster'], 'icon': stream['poster'], 'fanart': stream['poster']})

        url = f'{sys.argv[0]}?action=play&iframe={urllib.parse.quote(stream["iframe"])}'
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def router(params):
    if 'action' in params:
        if params['action'] == 'list_categories':
            list_categories()
        elif params['action'] == 'list_live_now':
            list_live_now()
        elif params['action'] == 'play':
            play_stream(params['iframe'])
    else:
        list_categories()

def play_stream(iframe_url):
    li = xbmcgui.ListItem(path=urllib.parse.unquote(iframe_url))
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)