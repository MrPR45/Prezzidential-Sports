import xbmcaddon
import xbmcgui
import xbmcplugin
import sys
from resources.lib.main import router

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')

if __name__ == '__main__':
    router(sys.argv)