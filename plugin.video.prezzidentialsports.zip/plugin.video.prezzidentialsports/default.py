import sys
import json
import time
import urllib.parse
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

try:
    import requests
except ImportError:
    import urllib.request

# Base API URL for fetching streams
BASE_API_URL = "https://ppv.land/api/streams"

# Get the addon instance and plugin handle
addon = xbmcaddon.Addon()
plugin_handle = int(sys.argv[1])

# Get the path to your logo from the resources folder (logo.png)
LOGO = os.path.join(addon.getAddonInfo('path'), 'resources', 'logo.png')

def build_url(query):
    """
    Constructs a plugin URL with the given query parameters.
    """
    return sys.argv[0] + "?" + urllib.parse.urlencode(query)

def fetch_api_data():
    """
    Fetches data from the general API endpoint.
    Returns the parsed JSON or None if an error occurs.
    """
    headers = {
        "User-Agent": "Kodi/PrezzidentialSportsAddon",
        "Referer": "https://ppv.land"
    }
    try:
        if "requests" in sys.modules:
            response = requests.get(BASE_API_URL, headers=headers, timeout=10)
            response.raise_for_status()
            return response.json()
        else:
            req = urllib.request.Request(BASE_API_URL, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as response:
                return json.loads(response.read().decode('utf-8'))
    except Exception as e:
        xbmcgui.Dialog().notification("Error", f"Failed to fetch API data: {e}", xbmcgui.NOTIFICATION_ERROR)
        return None

def add_main_menu():
    """
    Adds top-level menu items:
      1. Live Now
      2. Upcoming Games
      3. All Sports (Categories)
    """
    # Live Now
    url_live = build_url({"mode": "live_now"})
    li_live = xbmcgui.ListItem(label="Live Now (Currently Live)")
    infoTag = li_live.getVideoInfoTag()
    infoTag.setTitle("Live Now")
    li_live.setArt({'icon': LOGO, 'thumb': LOGO})
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url=url_live, listitem=li_live, isFolder=True)

    # Upcoming Games
    url_upcoming = build_url({"mode": "upcoming"})
    li_upcoming = xbmcgui.ListItem(label="Upcoming Games")
    infoTag = li_upcoming.getVideoInfoTag()
    infoTag.setTitle("Upcoming Games")
    li_upcoming.setArt({'icon': LOGO, 'thumb': LOGO})
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url=url_upcoming, listitem=li_upcoming, isFolder=True)

    # All Sports (Categories)
    url_all = build_url({"mode": "all_sports"})
    li_all = xbmcgui.ListItem(label="All Sports (Categories)")
    infoTag = li_all.getVideoInfoTag()
    infoTag.setTitle("All Sports")
    li_all.setArt({'icon': LOGO, 'thumb': LOGO})
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url=url_all, listitem=li_all, isFolder=True)

    xbmcplugin.endOfDirectory(plugin_handle)

def list_categories():
    """
    Lists all categories from the general API (e.g., Basketball, Football, etc.).
    """
    data = fetch_api_data()
    if not data:
        return

    categories = data.get("streams", [])
    for category in categories:
        category_id = category.get("id")
        category_name = category.get("category", "Unknown Category")
        url = build_url({"mode": "list_streams", "cat_id": category_id})
        li = xbmcgui.ListItem(label=category_name)
        infoTag = li.getVideoInfoTag()
        infoTag.setTitle(category_name)
        li.setArt({'icon': LOGO, 'thumb': LOGO})
        xbmcplugin.addDirectoryItem(handle=plugin_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(plugin_handle)

def list_streams_in_category(cat_id):
    """
    Lists all streams within a given category, sorted by start time.
    """
    data = fetch_api_data()
    if not data:
        return

    categories = data.get("streams", [])
    found_category = None
    for category in categories:
        if category.get("id") == cat_id:
            found_category = category
            break

    if not found_category:
        xbmcgui.Dialog().notification("Error", "Category not found", xbmcgui.NOTIFICATION_ERROR)
        return

    streams = found_category.get("streams", [])
    sorted_streams = sorted(streams, key=lambda s: s.get("starts_at") or 0)
    for stream in sorted_streams:
        add_stream_list_item(stream)
    xbmcplugin.endOfDirectory(plugin_handle)

def list_live_streams():
    """
    Lists only currently live streams (where now is between starts_at and ends_at or always_live is set),
    sorted in chronological order.
    """
    data = fetch_api_data()
    if not data:
        return

    now = int(time.time())
    live_streams = []
    categories = data.get("streams", [])
    for category in categories:
        for stream in category.get("streams", []):
            starts_at = stream.get("starts_at")
            ends_at = stream.get("ends_at")
            always_live = stream.get("always_live", 0)
            if always_live == 1 or (starts_at and ends_at and starts_at <= now <= ends_at):
                live_streams.append(stream)

    if not live_streams:
        xbmcgui.Dialog().notification("Info", "No live streams right now.", xbmcgui.NOTIFICATION_INFO)
    else:
        sorted_live_streams = sorted(live_streams, key=lambda s: s.get("starts_at") or 0)
        for stream in sorted_live_streams:
            add_stream_list_item(stream)
    xbmcplugin.endOfDirectory(plugin_handle)

def list_upcoming_streams():
    """
    Lists only upcoming streams (where starts_at is in the future), sorted in chronological order.
    """
    data = fetch_api_data()
    if not data:
        return

    now = int(time.time())
    upcoming_streams = []
    categories = data.get("streams", [])
    for category in categories:
        for stream in category.get("streams", []):
            starts_at = stream.get("starts_at")
            if starts_at and starts_at > now:
                upcoming_streams.append(stream)

    if not upcoming_streams:
        xbmcgui.Dialog().notification("Info", "No upcoming games found.", xbmcgui.NOTIFICATION_INFO)
    else:
        sorted_upcoming = sorted(upcoming_streams, key=lambda s: s.get("starts_at") or 0)
        for stream in sorted_upcoming:
            add_stream_list_item(stream)
    xbmcplugin.endOfDirectory(plugin_handle)

def add_stream_list_item(stream):
    """
    Helper function to add a single stream item to the directory,
    including its start time (if available) in the label.
    The time format is (HH:MM DD-MM-YYYY).
    Instead of passing a direct stream URL, we now pass the stream's ID.
    """
    stream_name = stream.get("name", "Untitled Stream")
    start_ts = stream.get("starts_at")
    if start_ts:
        local_time_str = time.strftime('%H:%M %d-%m-%Y', time.localtime(start_ts))
        display_name = f"{stream_name} (Starts: {local_time_str})"
    else:
        display_name = stream_name

    stream_id = stream.get("id")
    if not stream_id:
        uri_name = stream.get("uri_name", "")
        stream_id = uri_name  # Fallback

    url = build_url({"mode": "play", "stream_id": stream_id})
    li = xbmcgui.ListItem(label=display_name)
    infoTag = li.getVideoInfoTag()
    infoTag.setTitle(display_name)
    poster = stream.get("poster", "")
    if poster:
        li.setArt({'thumb': poster, 'icon': poster})
    else:
        li.setArt({'thumb': LOGO, 'icon': LOGO})
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=plugin_handle, url=url, listitem=li, isFolder=False)

def play_stream():
    """
    Plays the selected stream by polling the specific stream endpoint.
    Uses the stream_id to request /api/streams/<stream_id> and then
    extracts the m3u8 playlist URL from the "m3u8" key inside the "data" object.
    Debug logging is added to print the full JSON response so you can verify the structure.
    """
    params = urllib.parse.parse_qs(sys.argv[2][1:])
    stream_id = params.get("stream_id", [None])[0]
    if not stream_id:
        xbmcgui.Dialog().notification("Error", "No stream ID provided", xbmcgui.NOTIFICATION_ERROR)
        return

    stream_data_url = f"{BASE_API_URL}/{stream_id}"
    headers = {
        "User-Agent": "Kodi/PrezzidentialSportsAddon",
        "Referer": "https://ppv.land"
    }
    try:
        if "requests" in sys.modules:
            response = requests.get(stream_data_url, headers=headers, timeout=10)
            response.raise_for_status()
            stream_data = response.json()
        else:
            req = urllib.request.Request(stream_data_url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as response:
                stream_data = json.loads(response.read().decode('utf-8'))
    except Exception as e:
        xbmcgui.Dialog().notification("Error", f"Failed to fetch stream data: {e}", xbmcgui.NOTIFICATION_ERROR)
        return

    xbmc.log("Stream Data JSON: " + json.dumps(stream_data, indent=4), level=xbmc.LOGDEBUG)
    playlist_url = stream_data.get("data", {}).get("m3u8")
    if not playlist_url:
        xbmcgui.Dialog().notification("Error", "No m3u8 playlist URL found", xbmcgui.NOTIFICATION_ERROR)
        return

    li = xbmcgui.ListItem(path=playlist_url)
    xbmcplugin.setResolvedUrl(plugin_handle, True, li)

def router(paramstring):
    """
    Routes the plugin call based on the provided mode parameter.
    """
    params = urllib.parse.parse_qs(paramstring[1:])
    mode = params.get("mode", [None])[0]

    if mode is None:
        add_main_menu()
    elif mode == "live_now":
        list_live_streams()
    elif mode == "upcoming":
        list_upcoming_streams()
    elif mode == "all_sports":
        list_categories()
    elif mode == "list_streams":
        try:
            cat_id = int(params.get("cat_id")[0])
            list_streams_in_category(cat_id)
        except (TypeError, ValueError, IndexError):
            xbmcgui.Dialog().notification("Error", "Invalid category ID", xbmcgui.NOTIFICATION_ERROR)
    elif mode == "play":
        play_stream()
    else:
        xbmcgui.Dialog().notification("Error", f"Invalid mode: {mode}", xbmcgui.NOTIFICATION_ERROR)

if __name__ == '__main__':
    router(sys.argv[2])
