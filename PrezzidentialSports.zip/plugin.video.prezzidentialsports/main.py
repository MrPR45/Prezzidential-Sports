import sys
import xbmcplugin
import xbmcgui
import xbmcaddon
import urllib.parse
import requests
import json
import time

ADDON = xbmcaddon.Addon()
BASE_URL = "https://ppv.land/api/streams"

def build_url(query):
    return sys.argv[0] + "?" + urllib.parse.urlencode(query)

def get_json(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        return data if data.get("success") else {}
    except requests.RequestException:
        xbmcgui.Dialog().notification('Error', 'Failed to fetch data', xbmcgui.NOTIFICATION_ERROR)
        return {}

def list_categories():
    data = get_json(BASE_URL)
    if data:
        for category in data.get("streams", []):
            url = build_url({"mode": "list_streams", "category_id": category["id"]})
            li = xbmcgui.ListItem(category["category"])
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def list_streams(category_id):
    data = get_json(BASE_URL)
    if data:
        for category in data.get("streams", []):
            if category["id"] == int(category_id):
                for stream in category.get("streams", []):
                    url = build_url({"mode": "play", "iframe": stream.get("iframe")})
                    li = xbmcgui.ListItem(stream["name"])
                    li.setArt({'thumb': stream.get("poster", ""), 'icon': stream.get("poster", "")})
                    li.setInfo(type="Video", infoLabels={"Title": stream["name"], "Genre": category["category"]})
                    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def play_stream(iframe):
    if iframe:
        li = xbmcgui.ListItem(path=iframe)
        xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)
    else:
        xbmcgui.Dialog().notification('Error', 'Stream not available', xbmcgui.NOTIFICATION_ERROR)

def run():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = params.get("mode")
    if mode == "list_streams":
        list_streams(params["category_id"])
    elif mode == "play":
        play_stream(params.get("iframe"))
    else:
        list_categories()
