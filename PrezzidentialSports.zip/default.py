import xbmcaddon
import xbmcplugin
import xbmcgui
import sys
import os

addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')

def main():
    xbmcgui.Dialog().ok("Prezzidential Sports", "Welcome to Prezzidential Sports Add-on!")

if __name__ == "__main__":
    main()
