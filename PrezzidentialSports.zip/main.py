import requests
import xbmcplugin
import xbmcgui
import xbmcaddon
import sys
import time

API_URL = 'https://ppv.land/api/streams'
addon_handle = int(sys.argv[1])

def fetch_streams():
    try:
        response = requests.get(API_URL)
        data = response.json()
        if data.get('success'):
            return data.get('streams', [])
    except Exception as e:
        xbmcgui.Dialog().notification('Error', str(e), xbmcgui.NOTIFICATION_ERROR)
    return []

def list_main_menu():
    add_directory_item("🔴 Live Now", "live_now")
    add_directory_item("⏳ Upcoming Games", "upcoming")
    add_directory_item("📋 All Sports", "categories")
    xbmcplugin.endOfDirectory(addon_handle)

def list_categories():
    streams = fetch_streams()
    categories = {category['category'] for category in streams}
    for category in categories:
        add_directory_item(category, f"list_streams&category_id={category}")
    xbmcplugin.endOfDirectory(addon_handle)

def list_streams(category_name):
    streams = fetch_streams()
    for category in streams:
        if category['category'] == category_name:
            for stream in category['streams']:
                add_stream_item(stream, category['category'])
    xbmcplugin.endOfDirectory(addon_handle)

def list_live_now():
    current_time = int(time.time())
    streams = fetch_streams()
    for category in streams:
        for stream in category['streams']:
            if stream.get('starts_at') and stream.get('ends_at'):
                start_time = int(stream['starts_at'])
                end_time = int(stream['ends_at'])
                if start_time <= current_time <= end_time:
                    add_stream_item(stream, category['category'])
    xbmcplugin.endOfDirectory(addon_handle)

def list_upcoming():
    current_time = int(time.time())
    streams = fetch_streams()
    for category in streams:
        for stream in category['streams']:
            if stream.get('starts_at'):
                start_time = int(stream['starts_at'])
                if start_time > current_time:
                    add_stream_item(stream, category['category'])
    xbmcplugin.endOfDirectory(addon_handle)

def add_directory_item(name, action):
    li = xbmcgui.ListItem(label=name)
    url = f"{sys.argv[0]}?action={action}"
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

def add_stream_item(stream, category):
    li = xbmcgui.ListItem(label=stream['name'])
    li.setArt({'thumb': stream.get('poster', ''), 'icon': stream.get('poster', '')})
    li.setInfo('video', {'title': stream['name'], 'genre': category})
    li.setProperty('IsPlayable', 'true')
    url = f"{sys.argv[0]}?action=play&iframe_url={stream['iframe']}"
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

def play_stream(iframe_url):
    li = xbmcgui.ListItem(path=iframe_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)

if __name__ == '__main__':
    args = sys.argv[2][1:]
    params = dict(arg.split('=') for arg in args.split('&') if '=' in arg)
    action = params.get('action', '')

    if action == 'list_streams' and 'category_id' in params:
        list_streams(params['category_id'])
    elif action == 'live_now':
        list_live_now()
    elif action == 'upcoming':
        list_upcoming()
    elif action == 'play' and 'iframe_url' in params:
        play_stream(params['iframe_url'])
    else:
        list_main_menu()
